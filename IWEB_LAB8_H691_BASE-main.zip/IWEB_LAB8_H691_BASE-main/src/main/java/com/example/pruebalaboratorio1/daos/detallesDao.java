package com.example.pruebalaboratorio1.daos;

import com.example.pruebalaboratorio1.beans.Genero;
import com.example.pruebalaboratorio1.beans.Pelicula;

import java.sql.*;

public class detallesDao extends DaoBase {

    public Pelicula obtenerPelicula(int idPelicula) {

        Pelicula movie = new Pelicula();
        try {
            Connection conn = DriverManager.getConnection();
            Statement stmt = conn.createStatement();

            String sql = "SELECT A.*, B.NOMBRE FROM \n" +
                    "(SELECT * FROM PELICULA WHERE IDPELICULA = \n" +
                     idPelicula +
                    ") AS A \n" +
                    "INNER JOIN \n" +
                    "(SELECT * FROM GENERO) AS B\n" +
                    "ON A.IDGENERO = B.IDGENERO";
            // hacer el join con el genero y pedir que se haga por rating desc
            // agregar buscador

            ResultSet rs = stmt.executeQuery(sql);

            try (Connection conn = getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {


                while (rs.next()) {

                    Genero genero = new Genero();

                    int id = rs.getInt(1);
                    movie.setIdPelicula(id);
                    String titulo = rs.getString("titulo");
                    movie.setTitulo(titulo);
                    String director = rs.getString("director");
                    movie.setDirector(director);
                    int anoPublicacion = rs.getInt("anoPublicacion");
                    movie.setAnoPublicacion(anoPublicacion);
                    double rating = rs.getDouble("rating");
                    movie.setRating(rating);
                    double boxOffice = rs.getDouble("boxOffice");
                    movie.setBoxOffice(boxOffice);

                    String nombregenero = rs.getString("nombre");

                }

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return movie;
    }
}
