package com.example.pruebalaboratorio1.daos;

import com.example.pruebalaboratorio1.beans.Genero;
import com.example.pruebalaboratorio1.beans.streaming;

import java.util.ArrayList;

public class listasDao {

    public ArrayList<Genero> listarGeneros() {

        ArrayList<Genero> listaGeneros = new ArrayList<>();
        return listaGeneros;
    }

    public ArrayList<streaming> listarStraming() {

        ArrayList<streaming> listaStreaming = new ArrayList<>();
        return listaStreaming;
    }
}
