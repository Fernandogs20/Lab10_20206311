package com.example.pruebalaboratorio1.servlets;

import com.example.pruebalaboratorio1.beans.Pelicula;
import com.example.pruebalaboratorio1.daos.PeliculaDao;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
@WebServlet(name = "PeliculaServlet", urlPatterns = {"/peliculas"})
public class PeliculaServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action") == null ? "lista" : request.getParameter("action");

        PeliculaDao peliculaDao = new PeliculaDao();

        switch (action) {
            case "lista":
                List<Pelicula> peliculas = peliculaDao.obtenerTodasLasPeliculas();
                request.setAttribute("peliculas", peliculas);
                request.getRequestDispatcher("listaPeliculas.jsp").forward(request, response);
                break;

            case "eliminar":
                String idParam = request.getParameter("id");
                if (idParam != null) {
                    try {
                        int idPelicula = Integer.parseInt(idParam);
                        peliculaDao.eliminarPelicula(idPelicula);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                        response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de película no válido");
                        return;
                    }
                } else {
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "ID de película no proporcionado");
                    return;
                }
                response.sendRedirect("peliculas");
                break;

            case "buscar":
                String nombre = request.getParameter("nombre");
                List<Pelicula> peliculasFiltradas = peliculaDao.buscarPeliculasPorNombre(nombre);
                request.setAttribute("peliculas", peliculasFiltradas);
                request.getRequestDispatcher("listaPeliculas.jsp").forward(request, response);
                break;

            default:
                response.sendRedirect("peliculas?action=lista");
                break;
        }
    }


    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        response.setContentType("text/html");

        String action = request.getParameter("action");
        PeliculaDao peliculaDao = new PeliculaDao();
        //listasDao listaDao = new listasDao();
        //ArrayList<genero> listaGeneros = listaDao.listarGeneros();
        //ArrayList<streaming> listaStreaming = listaDao.listarStraming();

        switch (action) {


            case "filtrar":

                RequestDispatcher viewFiltro = request.getRequestDispatcher("listaPeliculas.jsp");
                viewFiltro.forward(request,response);
                break;

            case "editar":


                int idPelicula = Integer.parseInt(request.getParameter("idPelicula"));
                String titulo = request.getParameter("titulo");
                String director = request.getParameter("director");
                int anoPublicacion = Integer.parseInt(request.getParameter("anoPublicacion"));
                double rating = Double.parseDouble(request.getParameter("rating"));
                double boxOffice = Double.parseDouble(request.getParameter("boxOffice"));
                String genero = request.getParameter("genero");

//                peliculaDao.editarPelicula(idPelicula, titulo,director,anoPublicacion,rating,boxOffice);
//                response.sendRedirect(request.getContextPath()+"/listaPeliculas?action=listar");
//                break;


        }
    }


}